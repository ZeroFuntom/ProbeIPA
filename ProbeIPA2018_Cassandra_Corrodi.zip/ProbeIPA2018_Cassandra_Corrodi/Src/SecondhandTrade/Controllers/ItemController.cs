﻿using System.Web.Mvc;
using Secondhand.BusinessLogic.Teams;
using Secondhand.Domain.Model;
using Secondhand.Web.Models;

namespace SecondhandTrade.Controllers
{
    public class ItemController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Detail()
        {
            return View();
        }
    }
}